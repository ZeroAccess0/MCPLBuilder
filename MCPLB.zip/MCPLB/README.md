English version : 

MCPLB is an application that allows you to easily compile, decompile and create Minecraft plugins. MCPLB uses a custom GPT4 API and uses Gradle for plugin builds. There may be false positives when launching and downloading MCPLB. Don't worry, I'm currently working on it to reduce as much as possible.
Thank you for testing my software, hope you like it!

French version :

MCPLB est une application qui permet de compiler, décompiler et créer des plugins minecraft facilement. MCPLB utilise une API custom de GPT4 et utilise Gradle pour les compilations de plugin. Il peut y avoir des faux positifs au lancement et au téléchargement de MCPLB. Ne vous inquiétez pas, je travaille actuellement dessus pour en réduire un maximum.
Merci d'avoir testé mon logiciel, en espérant qu'il vous plaise !